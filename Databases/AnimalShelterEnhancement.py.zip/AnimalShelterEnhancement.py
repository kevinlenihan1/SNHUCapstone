from pymongo import MongoClient, ASCENDING, DESCENDING
from pymongo.errors import PyMongoError


class AnimalShelter:
    """Enhanced CRUD operations for an Animal collection in MongoDB."""

    def __init__(self, username, password, host, port, database, collection):

        try:
            self.client = MongoClient(
                f"mongodb://{username}:{password}@{host}:{port}/{database}",
                serverSelectionTimeoutMS=5000
            )

            # make sure the connection actually works
            self.client.admin.command("ping")

            self.database = self.client[database]
            self.collection = self.database[collection]

        except PyMongoError as e:
            raise ConnectionError(f"Could not connect to MongoDB: {e}")

    # create
    def create(self, data):

        if not isinstance(data, dict) or not data:
            raise ValueError("create() requires a non-empty dictionary.")

        try:
            result = self.collection.insert_one(data)
            return result.inserted_id

        except PyMongoError as e:
            raise RuntimeError(f"Create operation failed: {e}")

    # read records from the collection
    def read(self, query=None, projection=None, sort_field=None, sort_order="asc", limit=0):

        if query is None:
            query = {}

        if not isinstance(query, dict):
            raise ValueError("read() query must be a dictionary.")

        try:
            cursor = self.collection.find(query, projection)

            # optional sorting
            if sort_field:
                direction = ASCENDING if sort_order.lower() == "asc" else DESCENDING
                cursor = cursor.sort(sort_field, direction)

            # only return a certain number of records if needed
            if limit > 0:
                cursor = cursor.limit(limit)

            return list(cursor)

        except PyMongoError as e:
            raise RuntimeError(f"Read operation failed: {e}")

    # update matching records
    def update(self, query, update_data):

        if not isinstance(query, dict) or not query:
            raise ValueError("update() requires a non-empty query dictionary.")

        if not isinstance(update_data, dict) or not update_data:
            raise ValueError("update() requires a non-empty update dictionary.")

        try:
            result = self.collection.update_many(query, {"$set": update_data})
            return result.modified_count

        except PyMongoError as e:
            raise RuntimeError(f"Update operation failed: {e}")

    # delete matching records
    def delete(self, query):

        if not isinstance(query, dict) or not query:
            raise ValueError("delete() requires a non-empty query dictionary.")

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count

        except PyMongoError as e:
            raise RuntimeError(f"Delete operation failed: {e}")

    # aggregation
    def aggregate(self, pipeline):

        if not isinstance(pipeline, list) or not pipeline:
            raise ValueError("aggregate() requires a non-empty list pipeline.")

        try:
            return list(self.collection.aggregate(pipeline))

        except PyMongoError as e:
            raise RuntimeError(f"Aggregation operation failed: {e}")

    # create an index to help query performance
    def create_index(self, field_name, sort_order="asc"):

        if not field_name:
            raise ValueError("create_index() requires a field name.")

        try:
            direction = ASCENDING if sort_order.lower() == "asc" else DESCENDING
            return self.collection.create_index([(field_name, direction)])

        except PyMongoError as e:
            raise RuntimeError(f"Index creation failed: {e}")

    # close the database connection when done
    def close_connection(self):
        self.client.close()