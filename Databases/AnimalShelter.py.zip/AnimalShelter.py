from pymongo import MongoClient

class AnimalShelter:
    """CRUD operations for Animal collection in MongoDB"""

    def __init__(self, username, password, host, port, database, collection):
        # Build MongoDB connection string
        self.client = MongoClient(f'mongodb://{username}:{password}@{host}:{port}/{database}')
        self.database = self.client[database]
        self.collection = self.database[collection]

    # CREATE
    def create(self, data):
        if data is not None:
            insert_result = self.collection.insert_one(data)
            return insert_result.inserted_id is not None
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    # READ
    def read(self, query):
        if query is not None:
            return list(self.collection.find(query))
        else:
            return list(self.collection.find({}))

    # UPDATE
    def update(self, query, update_data):
        if query is not None and update_data is not None:
            result = self.collection.update_many(query, {"$set": update_data})
            return result.modified_count
        else:
            raise Exception("update() requires both query and update_data")

    # DELETE
    def delete(self, query):
        if query is not None:
            result = self.collection.delete_many(query)
            return result.deleted_count
        else:
            raise Exception("delete() requires a query parameter")
