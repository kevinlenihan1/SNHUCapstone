#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <limits>

struct Course {
    std::string courseNumber;
    std::string courseTitle;
    std::vector<std::string> prerequisites;

    // Constructor for easy initialization
    Course(std::string number, std::string title, std::vector<std::string> prereqs)
        : courseNumber(std::move(number)), courseTitle(std::move(title)), prerequisites(std::move(prereqs)) {}
};
struct TreeNode {
    Course course;
    TreeNode* left;
    TreeNode* right;

    explicit TreeNode(Course c) : course(std::move(c)), left(nullptr), right(nullptr) {}
};

class CourseTree {
private:
    TreeNode* root;

    // Helper function to insert into the BST
    TreeNode* insert(TreeNode* node, const Course& course) {
        if (node == nullptr) {
            return new TreeNode(course);
        }
        if (course.courseNumber < node->course.courseNumber) {
            node->left = insert(node->left, course);
        } else {
            node->right = insert(node->right, course);
        }
        return node;
    }

    // Helper function to print courses in alphanumeric order
    void inOrderPrint(TreeNode* node) const {
        if (node != nullptr) {
            inOrderPrint(node->left);
            std::cout << node->course.courseNumber << ": " << node->course.courseTitle << std::endl;
            inOrderPrint(node->right);
        }
    }

    // Helper function to search for a course
    TreeNode*
    search(TreeNode* node, const std::string& courseNumber) const {
        if (node == nullptr || node->course.courseNumber == courseNumber) {
            return node;
        }
        if (courseNumber < node->course.courseNumber) {
            return search(node->left, courseNumber);
        } else {
            return search(node->right, courseNumber);
        }
    }

public:
    CourseTree() : root(nullptr) {}

    void insert(const Course& course) {
        root = insert(root, course);
    }

    void printCourses() const {
        inOrderPrint(root);
    }

    [[nodiscard]] Course* findCourse(const std::string& courseNumber) const {
        TreeNode* result = search(root, courseNumber);
        return (result != nullptr) ? &result->course : nullptr;
    }
};

void loadCourseData(const std::string& filename, CourseTree& tree) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error: Unable to open file " << filename << "." << std::endl;
        return;
    }

    std::string line;
    while (getline(file, line)) {
        std::stringstream ss(line);
        std::string courseNumber, courseTitle, prereq;
        std::vector<std::string> prereqs;

        getline(ss, courseNumber, ',');
        if (courseNumber.empty()) {
            std::cerr << "Error: Invalid course number in file." << std::endl;
            continue;  // Skip invalid entries
        }

        getline(ss, courseTitle, ',');
        if (courseTitle.empty()) {
            std::cerr << "Error: Invalid course title for course " << courseNumber << std::endl;
            continue;  // Skip invalid entries
        }

        while (getline(ss, prereq, ',')) {
            prereqs.push_back(prereq);
        }

        Course course(courseNumber, courseTitle, prereqs);
        tree.insert(course);
    }
    file.close();
}

void displayMenu() {
    std::cout << "\nMenu Options:" << std::endl;
    std::cout << "1. Load course data" << std::endl;
    std::cout << "2. Print course list" << std::endl;
    std::cout << "3. Print course information" << std::endl;
    std::cout << "9. Exit" << std::endl;
}

int main() {
    CourseTree courseTree;
    int option;
    std::string filename, courseNumber;

    while (true) {
        displayMenu();
        std::cout << "Enter option: ";

        // Input validation for menu option
        if (!(std::cin >> option)) {
            std::cerr << "Invalid input. Please enter a number." << std::endl;
            std::cin.clear(); // Clear error flag
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Discard bad input
            continue;
        }

        switch (option) {
            case 1:
                std::cout << "Enter file name: ";
            std::cin >> filename;
            loadCourseData(filename, courseTree);
            break;
            case 2:
                std::cout << "Course List:\n";
            courseTree.printCourses();
            break;
            case 3:
                std::cout << "Enter course number: ";
            std::cin >> courseNumber;
            if (Course* course = courseTree.findCourse(courseNumber)) {
                std::cout << "Course: " << course->courseNumber << " - " << course->courseTitle << std::endl;
                std::cout << "Prerequisites: ";
                if (course->prerequisites.empty()) {
                    std::cout << "None";
                }
                else {
                    for (const std::string& prereq : course->prerequisites) {
                        std::cout << prereq << " ";
                    }
                }
                std::cout << std::endl;
            }
            else {
                std::cout << "Course not found." << std::endl;
            }
            break;
            case 9:
                std::cout << "Exiting..." << std::endl;
            return 0;
            default:
                std::cerr << "Invalid option. Please try again." << std::endl;
        }
    }
}
