#include <algorithm>
#include <cctype>
#include <fstream>
#include <iostream>
#include <limits>
#include <sstream>
#include <string>
#include <unordered_set>
#include <utility>
#include <vector>

struct Course {
    std::string courseNumber;
    std::string courseTitle;
    std::vector<std::string> prerequisites;

    Course() = default;

    Course(std::string number, std::string title, std::vector<std::string> prereqs)
        : courseNumber(std::move(number)),
          courseTitle(std::move(title)),
          prerequisites(std::move(prereqs)) {}
};

struct TreeNode {
    Course course;
    TreeNode* left;
    TreeNode* right;

    explicit TreeNode(Course c) : course(std::move(c)), left(nullptr), right(nullptr) {}
};

class CourseTree {
private:
    TreeNode* root;

    TreeNode* insert(TreeNode* node, const Course& course) {
        if (node == nullptr) {
            return new TreeNode(course);
        }

        if (course.courseNumber < node->course.courseNumber) {
            node->left = insert(node->left, course);
        }
        else if (course.courseNumber > node->course.courseNumber) {
            node->right = insert(node->right, course);
        }
        else {
            // If the course already exists, update the stored data instead of creating a duplicate node.
            node->course = course;
        }

        return node;
    }

    void inOrderPrint(TreeNode* node) const {
        if (node == nullptr) {
            return;
        }

        inOrderPrint(node->left);
        std::cout << node->course.courseNumber << ": " << node->course.courseTitle << std::endl;
        inOrderPrint(node->right);
    }

    TreeNode* search(TreeNode* node, const std::string& courseNumber) const {
        if (node == nullptr || node->course.courseNumber == courseNumber) {
            return node;
        }

        if (courseNumber < node->course.courseNumber) {
            return search(node->left, courseNumber);
        }

        return search(node->right, courseNumber);
    }

    TreeNode* findMin(TreeNode* node) const {
        while (node != nullptr && node->left != nullptr) {
            node = node->left;
        }
        return node;
    }

    TreeNode* remove(TreeNode* node, const std::string& courseNumber, bool& removed) {
        if (node == nullptr) {
            return nullptr;
        }

        if (courseNumber < node->course.courseNumber) {
            node->left = remove(node->left, courseNumber, removed);
        }
        else if (courseNumber > node->course.courseNumber) {
            node->right = remove(node->right, courseNumber, removed);
        }
        else {
            removed = true;

            // Case 1: No child nodes.
            if (node->left == nullptr && node->right == nullptr) {
                delete node;
                return nullptr;
            }

            // Case 2: One child node.
            if (node->left == nullptr) {
                TreeNode* temp = node->right;
                delete node;
                return temp;
            }

            if (node->right == nullptr) {
                TreeNode* temp = node->left;
                delete node;
                return temp;
            }

            // Case 3: Two child nodes.
            // Replace this node's course with the in-order successor from the right subtree.
            TreeNode* successor = findMin(node->right);
            node->course = successor->course;

            bool successorRemoved = false;
            node->right = remove(node->right, successor->course.courseNumber, successorRemoved);
        }

        return node;
    }

    void collectCourseNumbers(TreeNode* node, std::unordered_set<std::string>& courseNumbers) const {
        if (node == nullptr) {
            return;
        }

        collectCourseNumbers(node->left, courseNumbers);
        courseNumbers.insert(node->course.courseNumber);
        collectCourseNumbers(node->right, courseNumbers);
    }

    void validatePrerequisites(TreeNode* node, const std::unordered_set<std::string>& courseNumbers, bool& allValid) const {
        if (node == nullptr) {
            return;
        }

        validatePrerequisites(node->left, courseNumbers, allValid);

        for (const std::string& prereq : node->course.prerequisites) {
            if (!prereq.empty() && courseNumbers.find(prereq) == courseNumbers.end()) {
                std::cout << "Warning: " << node->course.courseNumber
                          << " lists missing prerequisite " << prereq << "." << std::endl;
                allValid = false;
            }
        }

        validatePrerequisites(node->right, courseNumbers, allValid);
    }

    void destroy(TreeNode* node) {
        if (node == nullptr) {
            return;
        }

        destroy(node->left);
        destroy(node->right);
        delete node;
    }

public:
    CourseTree() : root(nullptr) {}

    ~CourseTree() {
        clear();
    }

    CourseTree(const CourseTree&) = delete;
    CourseTree& operator=(const CourseTree&) = delete;

    void insert(const Course& course) {
        root = insert(root, course);
    }

    bool removeCourse(const std::string& courseNumber) {
        bool removed = false;
        root = remove(root, courseNumber, removed);
        return removed;
    }

    void printCourses() const {
        if (root == nullptr) {
            std::cout << "No course data has been loaded." << std::endl;
            return;
        }

        inOrderPrint(root);
    }

    [[nodiscard]] Course* findCourse(const std::string& courseNumber) const {
        TreeNode* result = search(root, courseNumber);
        return (result != nullptr) ? &result->course : nullptr;
    }

    bool validatePrerequisites() const {
        std::unordered_set<std::string> courseNumbers;
        collectCourseNumbers(root, courseNumbers);

        bool allValid = true;
        validatePrerequisites(root, courseNumbers, allValid);

        if (allValid) {
            std::cout << "All listed prerequisites were found in the loaded course data." << std::endl;
        }

        return allValid;
    }

    void clear() {
        destroy(root);
        root = nullptr;
    }
};

std::string trim(const std::string& value) {
    size_t start = 0;
    while (start < value.length() && std::isspace(static_cast<unsigned char>(value[start]))) {
        ++start;
    }

    size_t end = value.length();
    while (end > start && std::isspace(static_cast<unsigned char>(value[end - 1]))) {
        --end;
    }

    return value.substr(start, end - start);
}

std::string toUpper(std::string value) {
    std::transform(value.begin(), value.end(), value.begin(), [](unsigned char c) {
        return static_cast<char>(std::toupper(c));
    });
    return value;
}

bool loadCourseData(const std::string& filename, CourseTree& tree) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error: Unable to open file " << filename << "." << std::endl;
        return false;
    }

    tree.clear();

    std::string line;
    int lineNumber = 0;
    int loadedCourses = 0;

    while (getline(file, line)) {
        ++lineNumber;

        if (trim(line).empty()) {
            continue;
        }

        std::stringstream ss(line);
        std::string courseNumber;
        std::string courseTitle;
        std::string prereq;
        std::vector<std::string> prereqs;

        getline(ss, courseNumber, ',');
        courseNumber = toUpper(trim(courseNumber));

        if (courseNumber.empty()) {
            std::cerr << "Error: Missing course number on line " << lineNumber << "." << std::endl;
            continue;
        }

        getline(ss, courseTitle, ',');
        courseTitle = trim(courseTitle);

        if (courseTitle.empty()) {
            std::cerr << "Error: Missing course title for " << courseNumber
                      << " on line " << lineNumber << "." << std::endl;
            continue;
        }

        while (getline(ss, prereq, ',')) {
            prereq = toUpper(trim(prereq));
            if (!prereq.empty()) {
                prereqs.push_back(prereq);
            }
        }

        tree.insert(Course(courseNumber, courseTitle, prereqs));
        ++loadedCourses;
    }

    std::cout << loadedCourses << " course(s) loaded successfully." << std::endl;
    tree.validatePrerequisites();
    return true;
}

void displayCourse(const Course& course) {
    std::cout << "Course: " << course.courseNumber << " - " << course.courseTitle << std::endl;
    std::cout << "Prerequisites: ";

    if (course.prerequisites.empty()) {
        std::cout << "None";
    }
    else {
        for (size_t i = 0; i < course.prerequisites.size(); ++i) {
            std::cout << course.prerequisites[i];
            if (i < course.prerequisites.size() - 1) {
                std::cout << ", ";
            }
        }
    }

    std::cout << std::endl;
}

void displayMenu() {
    std::cout << "\nMenu Options:" << std::endl;
    std::cout << "1. Load course data" << std::endl;
    std::cout << "2. Print course list" << std::endl;
    std::cout << "3. Print course information" << std::endl;
    std::cout << "4. Delete a course" << std::endl;
    std::cout << "5. Validate prerequisites" << std::endl;
    std::cout << "9. Exit" << std::endl;
}

int main() {
    CourseTree courseTree;
    int option;
    std::string filename;
    std::string courseNumber;

    while (true) {
        displayMenu();
        std::cout << "Enter option: ";

        if (!(std::cin >> option)) {
            std::cerr << "Invalid input. Please enter a number." << std::endl;
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            continue;
        }

        switch (option) {
            case 1:
                std::cout << "Enter file name: ";
                std::cin >> filename;
                loadCourseData(filename, courseTree);
                break;

            case 2:
                std::cout << "Course List:" << std::endl;
                courseTree.printCourses();
                break;

            case 3:
                std::cout << "Enter course number: ";
                std::cin >> courseNumber;
                courseNumber = toUpper(trim(courseNumber));

                if (Course* course = courseTree.findCourse(courseNumber)) {
                    displayCourse(*course);
                }
                else {
                    std::cout << "Course not found." << std::endl;
                }
                break;

            case 4:
                std::cout << "Enter course number to delete: ";
                std::cin >> courseNumber;
                courseNumber = toUpper(trim(courseNumber));

                if (courseTree.removeCourse(courseNumber)) {
                    std::cout << courseNumber << " was deleted from the tree." << std::endl;
                }
                else {
                    std::cout << "Course not found. No course was deleted." << std::endl;
                }
                break;

            case 5:
                courseTree.validatePrerequisites();
                break;

            case 9:
                std::cout << "Exiting..." << std::endl;
                return 0;

            default:
                std::cerr << "Invalid option. Please try again." << std::endl;
        }
    }
}